import { createFileRoute, Link } from '@tanstack/react-router'
import { useSuspenseQuery } from '@tanstack/react-query'
import { convexQuery } from '@convex-dev/react-query'
import { api } from '../../convex/_generated/api'

export const Route = createFileRoute('/')({
  component: Home,
})

const IconUtensils = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 2v7c0 1.1.9 2 2 2h4a2 2 0 0 0 2-2V2"/><path d="M7 2v20"/><path d="M21 15V2v0a5 5 0 0 0-5 5v6c0 1.1.9 2 2 2h3Zm0 0v7"/></svg>
)

const IconClock = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
)

const IconMapPin = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>
)

const IconPhone = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
)

const IconStar = ({ fill = "none" }) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill={fill} stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
)

const IconChevronRight = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m9 18 6-6-6-6"/></svg>
)

const IconMenu = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="4" x2="20" y1="12" y2="12"/><line x1="4" x2="20" y1="6" y2="6"/><line x1="4" x2="20" y1="18" y2="18"/></svg>
)

function Home() {
  const { data: featuredItems } = useSuspenseQuery(convexQuery(api.menu.getFeaturedItems, {}));

  return (
    <div className="flex flex-col min-h-screen font-sans bg-white text-gray-900">
      {/* Navigation */}
      <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-sm border-b border-gray-100 shadow-sm">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="bg-red-700 text-white p-2 rounded-lg font-bold text-xl">AC</div>
            <span className="font-bold text-2xl tracking-tight text-gray-900">ADEN CAFE</span>
          </div>
          <nav className="hidden md:flex items-center gap-8 font-medium text-gray-600">
            <Link to="/" className="text-red-700">Home</Link>
            <Link to="/menu" className="hover:text-red-700 transition-colors">Menu</Link>
            <a href="#about" className="hover:text-red-700 transition-colors">About</a>
            <a href="#contact" className="hover:text-red-700 transition-colors">Contact</a>
          </nav>
          <div className="flex items-center gap-4">
            <Link to="/checkout" className="hidden sm:block px-5 py-2 bg-red-700 text-white rounded-full font-semibold hover:bg-red-800 transition-colors cursor-pointer">
              Order Online
            </Link>
            <button className="md:hidden text-gray-600 cursor-pointer">
              <IconMenu />
            </button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative h-[600px] flex items-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1541544741938-0af808871cc0?q=80&w=2069&auto=format&fit=crop" 
            alt="Middle Eastern Food Table" 
            className="w-full h-full object-cover brightness-50"
          />
        </div>
        <div className="container mx-auto px-4 relative z-10 text-white">
          <div className="max-w-2xl">
            <span className="inline-block px-3 py-1 bg-red-700/80 backdrop-blur-sm rounded-full text-sm font-semibold mb-4 uppercase tracking-wider">
              Norcross, GA
            </span>
            <h1 className="text-5xl md:text-7xl font-extrabold mb-6 leading-tight">
              Authentic <span className="text-orange-400">Yemeni</span> & Middle East Cuisine
            </h1>
            <p className="text-xl md:text-2xl mb-8 text-gray-200">
              Experience the rich flavors and traditional spices of Aden, served fresh daily in the heart of Norcross.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link to="/menu" className="px-8 py-4 bg-red-700 text-white rounded-full font-bold text-lg hover:bg-red-800 transition-all transform hover:scale-105 flex items-center justify-center gap-2 cursor-pointer">
                <IconUtensils />
                View Full Menu
              </Link>
              <Link to="/checkout" className="px-8 py-4 bg-white text-gray-900 rounded-full font-bold text-lg hover:bg-gray-100 transition-all transform hover:scale-105 flex items-center justify-center gap-2 cursor-pointer">
                Order Online
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Quick Info Strip */}
      <section className="bg-white border border-gray-100 shadow-xl relative z-20 -mt-10 mx-4 lg:mx-auto container rounded-2xl">
        <div className="grid grid-cols-1 md:grid-cols-3 divide-y md:divide-y-0 md:divide-x divide-gray-100">
          <div className="p-6 flex items-center gap-4">
            <div className="bg-orange-100 p-3 rounded-full text-orange-600">
              <IconMapPin />
            </div>
            <div>
              <h3 className="font-bold text-gray-900">Address</h3>
              <p className="text-gray-600">Norcross, GA 30093</p>
            </div>
          </div>
          <div className="p-6 flex items-center gap-4">
            <div className="bg-red-100 p-3 rounded-full text-red-600">
              <IconClock />
            </div>
            <div>
              <h3 className="font-bold text-gray-900">Hours</h3>
              <p className="text-gray-600">Open Daily: 11:00 AM - 10:00 PM</p>
            </div>
          </div>
          <div className="p-6 flex items-center gap-4">
            <div className="bg-green-100 p-3 rounded-full text-green-600">
              <IconPhone />
            </div>
            <div>
              <h3 className="font-bold text-gray-900">Contact</h3>
              <p className="text-gray-600">Call: (555) 123-4567</p>
            </div>
          </div>
        </div>
      </section>

      {/* Menu Preview */}
      <section id="menu" className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-bold text-gray-900 mb-4 tracking-tight">Our Signature Dishes</h2>
            <div className="w-24 h-1 bg-red-700 mx-auto"></div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {featuredItems.map((item) => (
              <div key={item._id} className="bg-white rounded-2xl overflow-hidden shadow-md hover:shadow-xl transition-shadow group">
                <div className="h-64 overflow-hidden relative">
                  {item.imageUrl && (
                    <img src={item.imageUrl} alt={item.name} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" />
                  )}
                  <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full font-bold text-red-700">
                    {item.price}
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="text-2xl font-bold mb-2 text-gray-900">{item.name}</h3>
                  <p className="text-gray-600 mb-4">{item.description}</p>
                  <Link to="/checkout" className="text-red-700 font-bold flex items-center gap-1 hover:gap-2 transition-all cursor-pointer">
                    Order Now <IconChevronRight />
                  </Link>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-12 text-center">
            <Link to="/menu" className="inline-block px-8 py-3 border-2 border-red-700 text-red-700 rounded-full font-bold hover:bg-red-700 hover:text-white transition-all cursor-pointer">
              View Full Menu
            </Link>
          </div>
        </div>
      </section>

      {/* Reviews */}
      <section className="py-20 bg-white overflow-hidden">
        <div className="container mx-auto px-4 relative">
          <div className="text-center mb-16">
            <div className="flex items-center justify-center gap-1 text-yellow-400 mb-2">
              {[1, 2, 3, 4, 5].map(i => <IconStar key={i} fill="currentColor" />)}
            </div>
            <h2 className="text-3xl md:text-5xl font-bold text-gray-900 mb-4">What Our Guests Say</h2>
            <p className="text-gray-600">Rated 4.8 stars from over 200 Google Reviews</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                text: "Best Mandi I've had outside of Yemen. The chicken was falling off the bone and the rice was perfectly seasoned.",
                author: "Sarah J."
              },
              {
                text: "A hidden gem in Norcross! The staff is so welcoming and the Haneeth is simply incredible. Definitely coming back.",
                author: "Michael R."
              },
              {
                text: "Authentic atmosphere and even better food. The tea is the perfect way to end a meal here.",
                author: "Ahmed K."
              }
            ].map((review, idx) => (
              <div key={idx} className="p-8 border border-gray-100 rounded-2xl bg-gray-50 relative">
                <span className="text-6xl text-red-100 absolute top-4 left-4 font-serif leading-none">"</span>
                <p className="text-gray-700 mb-6 relative z-10 italic">
                  {review.text}
                </p>
                <div className="flex items-center gap-2">
                  <div className="w-10 h-10 rounded-full bg-red-700 flex items-center justify-center text-white font-bold">
                    {review.author[0]}
                  </div>
                  <span className="font-bold text-gray-900">{review.author}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white pt-16 pb-8">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
            <div className="col-span-1 md:col-span-2">
              <div className="flex items-center gap-2 mb-6">
                <div className="bg-red-700 text-white p-2 rounded-lg font-bold text-xl">AC</div>
                <span className="font-bold text-2xl tracking-tight">ADEN CAFE</span>
              </div>
              <p className="text-gray-400 max-w-sm mb-6">
                Bringing the authentic tastes of Yemen to Norcross. Our recipes are passed down through generations, ensuring every bite is a journey to the heart of the Middle East.
              </p>
              <div className="flex gap-4">
                <div className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center hover:bg-red-700 transition-colors cursor-pointer">
                  <span className="font-bold">f</span>
                </div>
                <div className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center hover:bg-red-700 transition-colors cursor-pointer">
                  <span className="font-bold">in</span>
                </div>
                <div className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center hover:bg-red-700 transition-colors cursor-pointer">
                  <span className="font-bold">ig</span>
                </div>
              </div>
            </div>
            <div>
              <h3 className="text-lg font-bold mb-6">Quick Links</h3>
              <ul className="space-y-4 text-gray-400">
                <li><a href="#" className="hover:text-white transition-colors">Menu</a></li>
                <li><a href="#" className="hover:text-white transition-colors">About Us</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Order Online</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Contact</a></li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-bold mb-6">Contact Us</h3>
              <ul className="space-y-4 text-gray-400">
                <li className="flex items-start gap-3">
                  <IconMapPin />
                  <span>Norcross, GA 30093</span>
                </li>
                <li className="flex items-center gap-3">
                  <IconPhone />
                  <span>(555) 123-4567</span>
                </li>
                <li className="flex items-center gap-3">
                  <IconClock />
                  <span>Mon-Sun: 11AM - 10PM</span>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 pt-8 flex flex-col md:row justify-between items-center text-gray-500 text-sm">
            <p>© {new Date().getFullYear()} Aden Cafe & Restaurant. All rights reserved.</p>
            <div className="flex gap-6 mt-4 md:mt-0">
              <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
              <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
