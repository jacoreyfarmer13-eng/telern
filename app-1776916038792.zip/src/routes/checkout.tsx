import { createFileRoute, Link } from '@tanstack/react-router'
import { useState } from 'react'

export const Route = createFileRoute('/checkout')({
  component: CheckoutPage,
})

const IconArrowLeft = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m12 19-7-7 7-7"/><path d="M19 12H5"/></svg>
)

const IconCreditCard = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect width="20" height="14" x="2" y="5" rx="2"/><line x1="2" x2="22" y1="10" y2="10"/></svg>
)

const IconShoppingBag = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z"/><line x1="3" x2="21" y1="6" y2="6"/><path d="M16 10a4 4 0 0 1-8 0"/></svg>
)

function CheckoutPage() {
  const [isSubmitted, setIsSubmitted] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitted(true)
  }

  if (isSubmitted) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4 font-sans">
        <div className="bg-white p-8 rounded-2xl shadow-xl max-w-md w-full text-center">
          <div className="w-20 h-20 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-6">
            <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Order Received!</h1>
          <p className="text-gray-600 mb-8">
            Thank you for ordering from Aden Cafe. We're preparing your authentic Yemeni meal right now.
          </p>
          <Link to="/" className="inline-block w-full py-4 bg-red-700 text-white rounded-xl font-bold hover:bg-red-800 transition-colors">
            Back to Home
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 font-sans text-gray-900">
      <header className="bg-white border-b border-gray-100 py-6">
        <div className="container mx-auto px-4 flex items-center justify-between">
          <Link to="/menu" className="flex items-center gap-2 text-gray-600 hover:text-red-700 transition-colors font-semibold">
            <IconArrowLeft /> Back to Menu
          </Link>
          <div className="flex items-center gap-2">
            <div className="bg-red-700 text-white p-1.5 rounded-lg font-bold text-sm">AC</div>
            <span className="font-bold text-xl tracking-tight">ADEN CAFE</span>
          </div>
          <div className="w-24"></div> {/* Spacer for symmetry */}
        </div>
      </header>

      <main className="container mx-auto px-4 py-12">
        <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Checkout Form */}
          <div className="lg:col-span-2">
            <h2 className="text-3xl font-bold mb-8 flex items-center gap-3">
              <IconShoppingBag /> Checkout Details
            </h2>
            
            <form onSubmit={handleSubmit} className="space-y-8">
              {/* Contact Information */}
              <section className="bg-white p-6 md:p-8 rounded-2xl shadow-sm border border-gray-100">
                <h3 className="text-xl font-bold mb-6 text-gray-900 border-b border-gray-50 pb-4">Contact Information</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-bold text-gray-700 mb-2">Full Name</label>
                    <input required type="text" className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-red-700 focus:border-transparent outline-none transition-all" placeholder="John Doe" />
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-gray-700 mb-2">Phone Number</label>
                    <input required type="tel" className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-red-700 focus:border-transparent outline-none transition-all" placeholder="(555) 000-0000" />
                  </div>
                  <div className="md:col-span-2">
                    <label className="block text-sm font-bold text-gray-700 mb-2">Email Address</label>
                    <input required type="email" className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-red-700 focus:border-transparent outline-none transition-all" placeholder="john@example.com" />
                  </div>
                </div>
              </section>

              {/* Order Type */}
              <section className="bg-white p-6 md:p-8 rounded-2xl shadow-sm border border-gray-100">
                <h3 className="text-xl font-bold mb-6 text-gray-900 border-b border-gray-50 pb-4">Order Type</h3>
                <div className="flex gap-4">
                  <label className="flex-1 cursor-pointer">
                    <input type="radio" name="orderType" className="sr-only peer" defaultChecked />
                    <div className="p-4 text-center rounded-xl border-2 border-gray-100 peer-checked:border-red-700 peer-checked:bg-red-50 transition-all font-bold">
                      Pickup
                    </div>
                  </label>
                  <label className="flex-1 cursor-pointer">
                    <input type="radio" name="orderType" className="sr-only peer" />
                    <div className="p-4 text-center rounded-xl border-2 border-gray-100 peer-checked:border-red-700 peer-checked:bg-red-50 transition-all font-bold">
                      Delivery
                    </div>
                  </label>
                </div>
              </section>

              {/* Payment */}
              <section className="bg-white p-6 md:p-8 rounded-2xl shadow-sm border border-gray-100">
                <h3 className="text-xl font-bold mb-6 text-gray-900 border-b border-gray-50 pb-4 flex items-center gap-2">
                  <IconCreditCard /> Payment Information
                </h3>
                <div className="space-y-6">
                  <div>
                    <label className="block text-sm font-bold text-gray-700 mb-2">Card Number</label>
                    <input required type="text" className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-red-700 focus:border-transparent outline-none transition-all" placeholder="0000 0000 0000 0000" />
                  </div>
                  <div className="grid grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-bold text-gray-700 mb-2">Expiry Date</label>
                      <input required type="text" className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-red-700 focus:border-transparent outline-none transition-all" placeholder="MM/YY" />
                    </div>
                    <div>
                      <label className="block text-sm font-bold text-gray-700 mb-2">CVV</label>
                      <input required type="text" className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-red-700 focus:border-transparent outline-none transition-all" placeholder="123" />
                    </div>
                  </div>
                </div>
              </section>

              <button type="submit" className="w-full py-5 bg-red-700 text-white rounded-2xl font-bold text-xl hover:bg-red-800 transition-all shadow-lg hover:shadow-xl transform hover:-translate-y-1">
                Place My Order
              </button>
            </form>
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <div className="bg-white p-6 md:p-8 rounded-2xl shadow-sm border border-gray-100 sticky top-28">
              <h3 className="text-xl font-bold mb-6 text-gray-900 border-b border-gray-50 pb-4">Order Summary</h3>
              
              <div className="space-y-4 mb-8">
                <div className="flex justify-between items-center text-gray-600">
                  <span>Mandi Chicken (x1)</span>
                  <span className="font-bold text-gray-900">$14.99</span>
                </div>
                <div className="flex justify-between items-center text-gray-600">
                  <span>Yemeni Tea (x2)</span>
                  <span className="font-bold text-gray-900">$5.98</span>
                </div>
              </div>

              <div className="space-y-3 pt-6 border-t border-gray-100">
                <div className="flex justify-between text-gray-600">
                  <span>Subtotal</span>
                  <span>$20.97</span>
                </div>
                <div className="flex justify-between text-gray-600">
                  <span>Tax (7%)</span>
                  <span>$1.47</span>
                </div>
                <div className="flex justify-between text-2xl font-bold text-gray-900 pt-3">
                  <span>Total</span>
                  <span className="text-red-700">$22.44</span>
                </div>
              </div>

              <div className="mt-8 p-4 bg-orange-50 rounded-xl border border-orange-100 flex items-start gap-3">
                <div className="text-orange-600 mt-1">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" x2="12" y1="8" y2="12"/><line x1="12" x2="12.01" y1="16" y2="16"/></svg>
                </div>
                <p className="text-sm text-orange-800">
                  Orders usually take <span className="font-bold">25-35 minutes</span> to be ready for pickup.
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
