import { createFileRoute, Link } from '@tanstack/react-router'
import { useSuspenseQuery } from '@tanstack/react-query'
import { convexQuery } from '@convex-dev/react-query'
import { api } from '../../convex/_generated/api'

export const Route = createFileRoute('/menu')({
  component: MenuPage,
})

const IconArrowLeft = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m12 19-7-7 7-7"/><path d="M19 12H5"/></svg>
)

function MenuPage() {
  const { data: menuData } = useSuspenseQuery(convexQuery(api.menu.getFullMenu, {}));

  return (
    <div className="flex flex-col min-h-screen font-sans bg-white text-gray-900">
      {/* Menu Header */}
      <header className="bg-red-700 text-white py-12 md:py-20">
        <div className="container mx-auto px-4">
          <Link to="/" className="inline-flex items-center gap-2 text-red-100 hover:text-white mb-8 transition-colors">
            <IconArrowLeft /> Back to Home
          </Link>
          <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight">Our Menu</h1>
          <p className="text-xl text-red-100 mt-4 max-w-2xl">
            Discover the rich flavors of traditional Yemeni and Middle Eastern cuisine, prepared with authentic spices and fresh ingredients.
          </p>
        </div>
      </header>

      {/* Menu Navigation (Categories) */}
      <div className="sticky top-0 z-40 bg-white border-b border-gray-100 shadow-sm overflow-x-auto">
        <div className="container mx-auto px-4 flex whitespace-nowrap gap-8 py-4">
          {menuData.map((cat) => (
            <a 
              key={cat.category} 
              href={`#${cat.category.toLowerCase().replace(/\s+/g, '-')}`}
              className="font-bold text-gray-600 hover:text-red-700 transition-colors uppercase tracking-wider text-sm"
            >
              {cat.category}
            </a>
          ))}
        </div>
      </div>

      {/* Menu Content */}
      <main className="flex-1 py-16">
        <div className="container mx-auto px-4 max-w-4xl">
          {menuData.map((categoryData) => (
            <section 
              key={categoryData.category} 
              id={categoryData.category.toLowerCase().replace(/\s+/g, '-')}
              className="mb-20 scroll-mt-24"
            >
              <div className="flex items-center gap-4 mb-10">
                <h2 className="text-3xl font-bold text-gray-900">{categoryData.category}</h2>
                <div className="flex-1 h-px bg-gray-100"></div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-10">
                {categoryData.items.map((item) => (
                  <div key={item._id} className="flex gap-4 group">
                    {item.imageUrl && (
                      <div className="w-24 h-24 shrink-0 rounded-lg overflow-hidden hidden sm:block">
                        <img src={item.imageUrl} alt={item.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300" />
                      </div>
                    )}
                    <div className="flex-1">
                      <div className="flex justify-between items-baseline mb-1">
                        <Link to="/checkout" className="group/title">
                          <h3 className="text-xl font-bold text-gray-900 group-hover/title:text-red-700 transition-colors">{item.name}</h3>
                        </Link>
                        <span className="font-bold text-red-700">{item.price}</span>
                      </div>
                      <p className="text-gray-600 text-sm leading-relaxed mb-2">{item.description}</p>
                      <Link to="/checkout" className="text-xs font-bold text-red-700 hover:underline uppercase tracking-wider">
                        Order Now
                      </Link>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          ))}
        </div>
      </main>

      {/* Footer (Simplified) */}
      <footer className="bg-gray-50 border-t border-gray-100 py-12">
        <div className="container mx-auto px-4 text-center">
          <div className="flex items-center justify-center gap-2 mb-6">
            <div className="bg-red-700 text-white p-2 rounded-lg font-bold text-xl">AC</div>
            <span className="font-bold text-2xl tracking-tight">ADEN CAFE</span>
          </div>
          <p className="text-gray-500 mb-8">Authentic Yemeni & Middle East Cuisine in Norcross, GA</p>
          <div className="flex justify-center gap-8 text-gray-400">
            <a href="#" className="hover:text-red-700 transition-colors font-bold">Facebook</a>
            <a href="#" className="hover:text-red-700 transition-colors font-bold">Instagram</a>
            <a href="#" className="hover:text-red-700 transition-colors font-bold">Twitter</a>
          </div>
        </div>
      </footer>
    </div>
  )
}
