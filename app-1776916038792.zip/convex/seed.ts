import { mutation } from "./_generated/server";
import { v } from "convex/values";

export const seed = mutation({
  args: {},
  returns: v.null(),
  handler: async (ctx) => {
    // Clear existing data
    const categories = await ctx.db.query("menuCategories").collect();
    for (const category of categories) {
      await ctx.db.delete(category._id);
    }
    const items = await ctx.db.query("menuItems").collect();
    for (const item of items) {
      await ctx.db.delete(item._id);
    }

    // Insert categories
    const shawarmaId = await ctx.db.insert("menuCategories", { name: "Chicken Shawarma", order: 1 });
    const wrapsId = await ctx.db.insert("menuCategories", { name: "Wraps", order: 2 });
    const kidsId = await ctx.db.insert("menuCategories", { name: "Kids Menu", order: 3 });
    const sidesId = await ctx.db.insert("menuCategories", { name: "Side", order: 4 });
    const drinksId = await ctx.db.insert("menuCategories", { name: "Drinks", order: 5 });
    const dessertId = await ctx.db.insert("menuCategories", { name: "Dessert", order: 6 });
    const signatureId = await ctx.db.insert("menuCategories", { name: "Signature Dishes", order: 7 });

    // Chicken Shawarma
    await ctx.db.insert("menuItems", {
      categoryId: shawarmaId,
      name: "Chicken Shawarma Wrap",
      description: "Chicken shawarma with pickle, tomato, onion and lettuce.",
      price: "$9.99",
      isFeatured: true,
      order: 1,
    });
    await ctx.db.insert("menuItems", {
      categoryId: shawarmaId,
      name: "Chicken Shawarma Over Rice",
      description: "Chicken shawarma with rice hot sauce, garlic sauce and special sauce.",
      price: "$11.99",
      isFeatured: true,
      order: 2,
    });
    await ctx.db.insert("menuItems", {
      categoryId: shawarmaId,
      name: "Chicken Shawarma Over Salad",
      description: "Chicken shawarma with salad.",
      price: "$9.99",
      isFeatured: false,
      order: 3,
    });

    // Wraps
    await ctx.db.insert("menuItems", {
      categoryId: wrapsId,
      name: "Flafel Wrap",
      description: "Flafel wrap with pickle, tomato, onion and lettuce.",
      price: "$8.99",
      isFeatured: false,
      order: 1,
    });

    // Kids Menu
    await ctx.db.insert("menuItems", {
      categoryId: kidsId,
      name: "Chicken Nuggets",
      description: "6 pcs chicken nuggets comes with fries.",
      price: "$7.99",
      isFeatured: false,
      order: 1,
    });
    await ctx.db.insert("menuItems", {
      categoryId: kidsId,
      name: "Chicken Tenders",
      description: "4 chicken tenders comes with fries.",
      price: "$7.99",
      isFeatured: false,
      order: 2,
    });

    // Side
    await ctx.db.insert("menuItems", {
      categoryId: sidesId,
      name: "Rice",
      description: "Aromatic seasoned rice.",
      price: "$4.99",
      isFeatured: false,
      order: 1,
    });
    await ctx.db.insert("menuItems", {
      categoryId: sidesId,
      name: "Bread",
      description: "Freshly baked traditional bread.",
      price: "$1.99",
      isFeatured: false,
      order: 2,
    });
    await ctx.db.insert("menuItems", {
      categoryId: sidesId,
      name: "Fries",
      description: "Crispy golden french fries.",
      price: "$3.99",
      isFeatured: false,
      order: 3,
    });

    // Drinks
    await ctx.db.insert("menuItems", {
      categoryId: drinksId,
      name: "Adeni Tea With Milk",
      description: "Strong traditional tea brewed with milk and aromatic spices.",
      price: "$2.49",
      isFeatured: true,
      order: 1,
    });
    await ctx.db.insert("menuItems", {
      categoryId: drinksId,
      name: "Regular Red Tea With Yemeni Spices",
      description: "Black tea infused with cardamom and cloves.",
      price: "$1.99",
      isFeatured: false,
      order: 2,
    });
    await ctx.db.insert("menuItems", {
      categoryId: drinksId,
      name: "Soft Drink",
      description: "Choice of carbonated beverage.",
      price: "$1.99",
      isFeatured: false,
      order: 3,
    });
    await ctx.db.insert("menuItems", {
      categoryId: drinksId,
      name: "Water",
      description: "Bottled spring water.",
      price: "$1.49",
      isFeatured: false,
      order: 4,
    });
    await ctx.db.insert("menuItems", {
      categoryId: drinksId,
      name: "Lemonade",
      description: "Refreshing house-made lemonade.",
      price: "$2.49",
      isFeatured: false,
      order: 5,
    });
    await ctx.db.insert("menuItems", {
      categoryId: drinksId,
      name: "Mango",
      description: "Fresh mango juice.",
      price: "$4.99",
      isFeatured: false,
      order: 6,
    });

    // Dessert
    await ctx.db.insert("menuItems", {
      categoryId: dessertId,
      name: "Maasoob With Banana",
      description: "Traditional banana and bread pudding with honey and cream.",
      price: "$12.99",
      isFeatured: true,
      order: 1,
    });
    await ctx.db.insert("menuItems", {
      categoryId: dessertId,
      name: "Honey Comb",
      description: "Sweet pastry bread filled with cheese and drizzled with honey.",
      price: "$5.99",
      isFeatured: false,
      order: 2,
    });
    await ctx.db.insert("menuItems", {
      categoryId: dessertId,
      name: "Harissah/Basboosah",
      description: "Traditional semolina cake soaked in syrup.",
      price: "$1.99",
      isFeatured: false,
      order: 3,
    });

    // Signature Dishes (keeping some from before)
    await ctx.db.insert("menuItems", {
      categoryId: signatureId,
      name: "Mandi Chicken",
      description: "Traditional Yemeni rice dish with slow-cooked chicken and aromatic spices.",
      price: "$14.99",
      imageUrl: "https://images.unsplash.com/photo-1590594460030-2216d338f076?q=80&w=2070&auto=format&fit=crop",
      isFeatured: true,
      order: 1,
    });
    await ctx.db.insert("menuItems", {
      categoryId: signatureId,
      name: "Lamb Haneeth",
      description: "Tender lamb ribs slow-roasted to perfection with Yemeni spice blend.",
      price: "$18.99",
      imageUrl: "https://images.unsplash.com/photo-1603360946369-dc9bb6258143?q=80&w=2070&auto=format&fit=crop",
      isFeatured: true,
      order: 2,
    });

    return null;
  },
});
