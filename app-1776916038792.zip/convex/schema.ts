import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";

export default defineSchema({
  menuCategories: defineTable({
    name: v.string(), // e.g., "Breakfast", "Lunch", "Signature Dishes"
    order: v.number(),
  }),
  menuItems: defineTable({
    categoryId: v.id("menuCategories"),
    name: v.string(),
    description: v.string(),
    price: v.string(),
    imageUrl: v.optional(v.string()),
    isFeatured: v.boolean(),
    order: v.number(),
  })
  .index("by_category", ["categoryId"])
  .index("by_featured", ["isFeatured"]),
  reviews: defineTable({
    author: v.string(),
    text: v.string(),
    rating: v.number(),
    date: v.string(),
  }),
});
