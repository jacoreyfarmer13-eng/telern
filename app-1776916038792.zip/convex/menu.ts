import { query } from "./_generated/server";
import { v } from "convex/values";

export const getFeaturedItems = query({
  args: {},
  returns: v.array(
    v.object({
      _id: v.id("menuItems"),
      _creationTime: v.number(),
      categoryId: v.id("menuCategories"),
      name: v.string(),
      description: v.string(),
      price: v.string(),
      imageUrl: v.optional(v.string()),
      isFeatured: v.boolean(),
      order: v.number(),
    })
  ),
  handler: async (ctx) => {
    return await ctx.db
      .query("menuItems")
      .withIndex("by_featured", (q) => q.eq("isFeatured", true))
      .collect();
  },
});

export const getFullMenu = query({
  args: {},
  returns: v.array(
    v.object({
      category: v.string(),
      items: v.array(
        v.object({
          _id: v.id("menuItems"),
          _creationTime: v.number(),
          name: v.string(),
          description: v.string(),
          price: v.string(),
          imageUrl: v.optional(v.string()),
        })
      ),
    })
  ),
  handler: async (ctx) => {
    const categories = await ctx.db.query("menuCategories").order("asc").collect();
    const result = [];

    for (const category of categories) {
      const items = await ctx.db
        .query("menuItems")
        .withIndex("by_category", (q) => q.eq("categoryId", category._id))
        .collect();
      
      result.push({
        category: category.name,
        items: items.map(item => ({
          _id: item._id,
          _creationTime: item._creationTime,
          name: item.name,
          description: item.description,
          price: item.price,
          imageUrl: item.imageUrl,
        })),
      });
    }

    return result;
  },
});
